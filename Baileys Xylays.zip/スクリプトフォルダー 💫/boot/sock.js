import makeWASocket, {
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers
} from '@whiskeysockets/baileys';
import logger from '../フォルダレイ 🎩/logger.js';
import { Boom } from '@hapi/boom';
import { useMongoDBAuthState } from '../フォルダレイ 🎩/db-auth.js';
import { messageHandler } from '../Xylays — это разработчик👨‍💻/msg.js';

export async function startSock() {
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    version,
    logger,
    printQRInTerminal: true,
    browser: Browsers.macOS('Safari'),
    auth: state,
    getMessage: async (key) => {
      return { conversation: 'message not found' };
    }
  });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', ({ connection, lastDisconnect }) => {
    const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
    if (connection === 'close') {
      if (reason !== DisconnectReason.loggedOut) {
        startSock();
      } else {
        console.log('Logged out.');
      }
    } else if (connection === 'open') {
      console.log('Connected to WhatsApp Web!');
    }
  });

  sock.ev.on('messages.upsert', (m) => messageHandler(sock, m));
}