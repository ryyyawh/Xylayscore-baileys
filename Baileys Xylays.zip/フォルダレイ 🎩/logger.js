// Dummy auth state (replace if needed with DB support)
import { useMultiFileAuthState } from '@whiskeysockets/baileys';

export async function useMongoDBAuthState() {
  return await useMultiFileAuthState('./сеансов 🎰');
}