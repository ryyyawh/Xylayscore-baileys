export async function messageHandler(sock, { messages, type }) {
  if (type !== 'notify') return;
  const msg = messages[0];
  if (!msg.message) return;

  const from = msg.key.remoteJid;

  const text = msg.message.conversation ||
               msg.message.extendedTextMessage?.text ||
               msg.message.imageMessage?.caption;

  if (!text) return;

  if (text.toLowerCase() === 'ping') {
    await sock.sendMessage(from, { text: 'pong!' });
  }
}